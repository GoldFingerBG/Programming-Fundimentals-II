import java.util.ArrayList;

public interface FileWrite {
    void writeToFile(ArrayList<MedicalProvider>f);
}
