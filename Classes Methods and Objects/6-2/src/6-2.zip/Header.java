public class Header {
    public static void showHeader(){
        System.out.println("*******************************************");
        System.out.println("Welcome to the Alamo College Parking System");
        System.out.println("*******************************************");

    }
}
